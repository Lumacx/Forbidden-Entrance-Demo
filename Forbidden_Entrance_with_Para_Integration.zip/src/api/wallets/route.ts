import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const WALLETS_FILE = path.join(process.cwd(), "wallets.json");

interface Wallet {
  user: string;
  address: string;
}

// POST: Guardar una nueva wallet
export async function POST(request: Request) {
  try {
    // Verifica que el cuerpo de la solicitud sea un JSON válido
    const { user, address } = await request.json();

    if (!user || !address) {
      return NextResponse.json(
        { success: false, error: "Missing user or address" },
        { status: 400 }
      );
    }

    // Lee las wallets existentes o inicializa un array vacío
    const wallets = fs.existsSync(WALLETS_FILE)
      ? JSON.parse(fs.readFileSync(WALLETS_FILE, "utf-8"))
      : [];

    // Agrega la nueva wallet
    console.log("Received data:", { user, address });
    wallets.push({ user, address });

    // Guarda las wallets en el archivo
    fs.writeFileSync(WALLETS_FILE, JSON.stringify(wallets, null, 2));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error saving wallet:", error);
    return NextResponse.json(
      { success: false, error: "Internal Server Error" },
      { status: 500 }
    );
  }
}