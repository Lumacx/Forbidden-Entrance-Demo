"use client"; // Marca este componente como un Client Component

import { useEffect, useState } from "react";
import "@getpara/react-sdk/styles.css";

export default function GamePage() {
  const [player, setPlayer] = useState<string | null>(null);
  const [id, setId] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [shortenedWalletId, setShortenedWalletId] = useState<string | null>(null);

  useEffect(() => {
    // Verifica si estamos en el cliente antes de usar sessionStorage
    if (typeof window !== "undefined") {
      const player = sessionStorage.getItem("player");
      const id = sessionStorage.getItem("id");

      if (player && id) {
        setPlayer(player);
        setId(id);

        // 1. Extraer el nombre de la cuenta del correo electrónico
        const username = player.split("@")[0];
        setUsername(username);

        // 2. Acortar el walletId
        const walletSliced = id.slice(2, 5);
        const shortenedWalletId = "celestia1" + walletSliced + "..." + id.slice(-4);
        setShortenedWalletId(shortenedWalletId);
      }
    }
  }, []);

  return (
    <div style={{ 
      padding: "20px", 
      textAlign: "center", 
      backgroundColor: "black", // Fondo negro
      minHeight: "100vh", // Asegura que el fondo cubra toda la altura de la pantalla
      color: "#7b2bf9", // Color del texto principal
      position: "relative", // Necesario para posicionar el iframe
    }}>
      {/* Contenedor para la imagen y el iframe */}
      <div style={{ 
        position: "relative", 
        display: "inline-block", 
        width: "100%", // Ocupa el 100% del ancho del contenedor
        maxWidth: "1200px", // Limita el ancho máximo para evitar que se vea demasiado grande
      }}>
        {/* Imagen de fondo (la pared con la ventana) */}
        <img
          src="/images/intro2.jpg" // Ruta a tu imagen JPEG
          alt="Arcade Machine"
          style={{
            width: "100%", // Ocupa el 100% del ancho del contenedor
            height: "auto", // Mantiene la proporción de la imagen
            objectFit: "cover", // Asegura que la imagen cubra el espacio sin distorsionarse
          }}
        />

        {/* Wallet ID y Player ID en la esquina superior derecha */}
        <div style={{
          position: "absolute", // Posicionamiento absoluto
          top: "20px", // Distancia desde la parte superior
          left: "20px", // Distancia desde la derecha
          color: "white", // Color del texto
          backgroundColor: "rgba(0, 0, 0, 0.5)", // Fondo semitransparente
          padding: "10px", // Espaciado interno
          borderRadius: "5px", // Bordes redondeados
          zIndex: 1, // Asegura que esté encima de la imagen
        }}>
          {shortenedWalletId && <p>Wallet ID: {shortenedWalletId}</p>} {/* Muestra el walletId acortado */}
          {username && <p>Player ID: {username}</p>} {/* Muestra el nombre de la cuenta */}
        </div>

        {/* Iframe que carga el sitio externo */}
        <iframe
          src="https://itch.io/embed-upload/12959151?color=333333"
          style={{
            position: "absolute", // Posicionamiento absoluto
            top: "50%", // Centra verticalmente
            left: "50%", // Centra horizontalmente
            transform: "translate(-50%, -50%)", // Centra el iframe
            width: "40%", // Ocupa el 80% del ancho del contenedor
            height: "48%", // Ocupa el 60% del alto del contenedor
            aspectRatio: "16/9", // Mantiene la relación de aspecto (ajusta según sea necesario)
            border: "none",
          }}
          allowFullScreen
        />
        <a href="https://studio-swai.itch.io/forbidden-entrance"></a>
      </div>
    </div>
  );
}