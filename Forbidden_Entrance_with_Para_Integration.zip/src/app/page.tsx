"use client";

import { useEffect, useState } from "react";
import { AuthLayout, ParaModal, OAuthMethod } from "@getpara/react-sdk";
import { para, getCurrentUser, getWalletAddress } from "@/client/para";
import "@getpara/react-sdk/styles.css";
import ImageTable from '../components/ImageTable';
import Swal from 'sweetalert2';

// Define la interfaz para las props de MyComponent
interface MyComponentProps {
  isConnected: boolean;
  onContinue: () => void;
  onChangeUser: () => void;
}

// Mueve MyComponent fuera de Home
const MyComponent = ({ isConnected, onContinue, onChangeUser }: MyComponentProps) => {
  const [popupShown, setPopupShown] = useState(false);

  useEffect(() => {
    const showPopup = async () => {
      if (isConnected && !popupShown) {
        setPopupShown(true);

        try {
          const email = await getCurrentUser();
          Swal.fire({
            title: 'Mammothon Login',
            text: `You are currently logged as: ${email}. Do you want to continue?`,
            showCancelButton: true,
            confirmButtonText: 'Continue',
            cancelButtonText: 'Logout',
          }).then((result) => {
            if (result.isConfirmed) {
              onContinue();
            } else if (result.isDismissed) {
              onChangeUser();
            }
            setPopupShown(false);
          });
        } catch (error) {
          console.error("Error al obtener el correo electrónico:", error);
          setPopupShown(false);
        }
      }
    };

    showPopup();
  }, [isConnected, popupShown, onContinue, onChangeUser]);

  return (
    <div>
      {isConnected ? null : (
        <p style={{
          position: "absolute", // Posicionamiento absoluto
          top: "71%", // Distancia desde la parte superior
          left: "35%", // Distancia desde la izquierda
          color: "white", // Color del texto
          transform: "translate(-50%, -50%)", // Centra el texto
          backgroundColor: "rgba(0, 0, 0, 0.5)", // Fondo semitransparente
          padding: "10px", // Espaciado interno
          borderRadius: "5px", // Bordes redondeados
          zIndex: 1, // Asegura que esté encima de la imagen
        }}>
          You are not logged in.
        </p>
      )}
    </div>
  );
};

export default function Home() {
  const [isOpen, setIsOpen] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string>("");

  const handleCheckIfAuthenticated = async () => {
    setError("");
    try {
      const isAuthenticated = await para.isFullyLoggedIn();
      setIsConnected(isAuthenticated);
    } catch (err: any) {
      setError(err.message || "An error occurred during authentication");
    }
  };

  const handleOpenModal = () => {
    setIsOpen(true);
  };

  const handleCloseModal = async () => {
    handleCheckIfAuthenticated();
    setIsOpen(false);
  };

  const handleContinue = async () => {
    try {
      const wallet = await getWalletAddress();
      const email = await getCurrentUser();
  
      // Verifica si estamos en el cliente antes de usar sessionStorage
      if (typeof window !== "undefined") {
        sessionStorage.setItem("player", email);
        sessionStorage.setItem("id", wallet);
      }
  
      // Redirige a la nueva página sin parámetros en la URL
      window.location.href = "/game";
    } catch (err) {
      console.error("Error al obtener la dirección de la billetera:", err);
    }
  };

  const handleChangeUser = async () => {
    try {
      await para.logout();
      setIsConnected(false);
      window.location.href = "/";
    } catch (err) {
      console.error("Error al desconectar al usuario:", err);
    }
  };

  return (
    <main style={{
      position: "relative", // Necesario para el posicionamiento absoluto del mensaje
      minHeight: "100vh", // Cubre toda la altura de la pantalla
      backgroundColor: "black", // Fondo negro
      color: "white", // Color del texto
    }}>     
      {/* Contenido de la página */}
      <div style={{ backgroundColor: 'black', position: "relative", zIndex: 1 }}>
        <h1 className="text-2xl font-bold"></h1>
        <div className="page-container">
          <ImageTable onClick={handleOpenModal} />
        </div>
        <p className="max-w-md text-center"></p>
        <MyComponent
          isConnected={isConnected}
          onContinue={handleContinue}
          onChangeUser={handleChangeUser}
        />
        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
      </div>
      {/* Modal */}
      <ParaModal
        para={para}
        isOpen={isOpen}
        onClose={handleCloseModal}
        disableEmailLogin={false}
        disablePhoneLogin={false}
        authLayout={[AuthLayout.AUTH_FULL]}
        oAuthMethods={[
          OAuthMethod.GOOGLE,
        ]}
        onRampTestMode={true}
        theme={{
          foregroundColor: "#2D3648",
          backgroundColor: "#f6f6f6",
          accentColor: "#0066CC",
          darkForegroundColor: "#E8EBF2",
          darkBackgroundColor: "#1A1F2B",
          darkAccentColor: "#4D9FFF",
          mode: "light",
          borderRadius: "none",
          font: "Inter",
        }}
        appName="Para Modal Example"
        logo="http://studioswai.com/wp-content/uploads/2023/04/logo-v5.png"
        recoverySecretStepEnabled={true}
        twoFactorAuthEnabled={false}
      />
    </main>
  );
}