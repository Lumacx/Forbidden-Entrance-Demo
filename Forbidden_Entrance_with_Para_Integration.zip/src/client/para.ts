import { Environment, ParaWeb } from "@getpara/react-sdk";
//import { saveWallet } from "../utils/storage";

const PARA_API_KEY = process.env.NEXT_PUBLIC_PARA_API_KEY;

if (!PARA_API_KEY) {
  throw new Error("PARA_API_KEY is not set");
}

export const para = new ParaWeb(Environment.BETA, PARA_API_KEY);

// Función para obtener el usuario autenticado
export async function getCurrentUser(): Promise<string> {
  // Obtén el usuario autenticado desde el objeto `para`
  const email = await para.getEmail(); //.getUserId(); // .getCurrentUser(); // Asume que `para` tiene un método `getCurrentUser`
  // console.log("GETUSER:", { email });
  if (!email) {
    throw new Error("No user is currently authenticated");
  }
  return email; //. .name; // Asume que el objeto `user` tiene una propiedad `name`
}

// Función para obtener la dirección de la wallet
export async function getWalletAddress(): Promise<string> {
  // Obtén la wallet del usuario autenticado desde el objeto `para`
  const wallet = await para.getAddress(); //.getWallets(); // Asume que `para` tiene un método `getWallet`
  // console.log("GETWALLET:", { wallet });
  if (!wallet) {
    throw new Error("No wallet found for the current user");
  }
  return wallet; // Asume que el objeto `wallet` tiene una propiedad `address`
}

