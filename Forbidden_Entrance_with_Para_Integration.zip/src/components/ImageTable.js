// components/ImageTable.js
import Image from 'next/image';

const ImageTable = ({ onClick }) => {
  return (
    <div className="image-container" style={{ position: 'relative', width: '100%', height: 'auto' }}>
      <Image
        src="/images/intro2.jpg" // Reemplaza con la ruta de tu imagen
        alt="Imagen central"
        width={1538} // Ajusta el tamaño de la imagen
        height={1087} // Ajusta el tamaño de la imagen
        layout="responsive" // Hace que la imagen sea responsiva
        className="centered-image"
      />
      <div
        className="clickable-area"
        onClick={onClick}
        style={{
          position: 'absolute',
          top: '52.05%', // Ajusta según la posición deseada
          left: '51.2%', // Ajusta según la posición deseada
          transform: 'translate(-50%, -50%)',
          width: '14.3%', // Tamaño del área clickeable en porcentaje del ancho de la imagen
          height: '29%', // Tamaño del área clickeable en porcentaje del alto de la imagen
          //backgroundColor: 'rgba(255, 255, 255, 0.3)', // Fondo semitransparente
          borderRadius: '0%', // Hace que el área sea circular
          cursor: 'pointer', // Cambia el cursor al pasar sobre el área
        }}
      ></div>
    </div>
  );
};

export default ImageTable;